export const environment = {
  production: true,
  apiUrl: 'http://127.0.0.1:3300/api/v1' // Replace with your computer's IP address
};
