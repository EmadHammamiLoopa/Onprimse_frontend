import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-friends-header',
  templateUrl: './friends-header.component.html',
  styleUrls: ['./friends-header.component.scss'],
})
export class FriendsHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
