import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-and-sell',
  templateUrl: './buy-and-sell.page.html',
  styleUrls: ['./buy-and-sell.page.scss'],
})
export class BuyAndSellPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
