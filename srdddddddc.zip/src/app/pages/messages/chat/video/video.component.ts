import { Location } from '@angular/common';
import { ToastService } from './../../../../services/toast.service';
import { UserService } from './../../../../services/user.service';
import { User } from './../../../../models/User';
import { WebrtcService } from './../../../../services/webrtc.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { SocketService } from 'src/app/services/socket.service';
import { MessengerService } from './../../../messenger.service';
import { AdMobFeeService } from './../../../../services/admobfree.service';
import { Socket } from 'socket.io-client';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Subscription } from 'rxjs';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Platform } from '@ionic/angular';
import { MediaConnection } from 'peerjs';
import { NgZone } from '@angular/core';
import { RingerService } from 'src/app/services/ringer.service';
import { VideoEvents } from './events';

@Component({
  selector: 'app-video',
  templateUrl: './video.component.html',
  styleUrls: ['./video.component.scss'],
})
export class VideoComponent implements OnInit, OnDestroy {
  calling = false;
  @ViewChild('partnerVideo', { static: false })
  private partnerVideoRef!: ElementRef<HTMLVideoElement>;
  pageLoading = false;
  topVideoFrame = 'partner-video';
  authUser: User; // ✅ The logged-in user
  partnerUser: User; // ✅ The recipient user (partner in the call)
  myEl: HTMLVideoElement;
  partnerEl: HTMLVideoElement;
  public partnerId?: string;
  public userId?: string;
  partner: User = new User();
  user: User = new User();
  answer = false;
  answered = false;
  socket: Socket | null = null; // Use the Socket type from socket.io-client
  audio: HTMLAudioElement;
  audioEnabled = true;
  cameraEnabled = true;
  localStream: MediaStream | null = null;
  jwtHelper = new JwtHelperService();
  private callTimer: any; // For storing the timer reference
  partnerName: string;
  placingCall = false;
  private hangupHandled = false; 
  answeringCall = false;
endingCall = false;
switchingCamera = false;
callTimeout: any = null;

callDuration: string = '00:00';
private callStartTime: number | null = null;
private callTimerInterval: any;
private unansweredTimeout: any;

// Add to your component
@ViewChild('myVideo',      { static: false }) myVideoRef:      ElementRef<HTMLVideoElement>;
  private callStateSubscription: Subscription;
  private connectionSubscriptions: Subscription[] = [];

  private partnerAnsweredListener: () => void;
  private backButtonSubscription: Subscription;
  private isRemoteEnd: boolean = false;

  constructor(
    public webRTC: WebrtcService,
    public elRef: ElementRef,
    private route: ActivatedRoute,
    private userService: UserService,
    private toastService: ToastService,
    private location: Location,
    private nativeStorage: NativeStorage,
    private router: Router,
    private messengerService: MessengerService,
    private adMobFeeService: AdMobFeeService,
    private socketService: SocketService,
    private cdr: ChangeDetectorRef,
    private platform: Platform,
    private ngZone: NgZone,
    private ringer: RingerService

    
  ) {    this.partnerAnsweredListener = () => {
    console.log("🎉 Partner has answered the call (class handler)");
    this.answered = true;
    this.cdr.detectChanges();
  };
}

ngAfterViewInit() {
  if (this.myVideoRef && this.partnerVideoRef) {
    this.webRTC.setVideoElements(this.myVideoRef.nativeElement,
                                 this.partnerVideoRef.nativeElement);
  }

  // run again when change-detection adds the videos
  this.cdr.detectChanges();
}


/* ─── and always deregister on leave/destroy —───────────────────────────── */
ionViewWillLeave() { this.webRTC.clearVideoElements(); }
ngOnDestroy()      { this.webRTC.clearVideoElements(); }
async ngOnInit() {
  /* ── 1 ▸ diagnostics & device list ──────────────────────────────── */
  console.log('📞 Initializing Video Call Component…');
  this.webRTC.listAllMediaDevices();

  /* ── 2 ▸ react to call-state changes (connected / ended) ─────────── */
  this.callStateSubscription = this.webRTC.callState$
    .subscribe(state => {
      if (state?.connected) {
        this.answered = true;
        this.calling  = false;
        this.startCallTimer();
        this.ringer.stop();
        this.clearUnansweredTimeout();
      } else if (state === null) {
        this.stopCallTimer();
        this.answered = false;
        this.ringer.stop();
      }
      this.cdr.detectChanges();
    });

  /* ── 3 ▸ Android hardware-back button ────────────────────────────── */
  this.backButtonSubscription = this.platform.backButton
    .subscribeWithPriority(10, () => this.handleBackButton());

  /* ── 4 ▸ authentication → socket → route params ─────────────────── */
  try {
    await this.getAuthUser();                               // fills this.authUser
    await this.initializeSocket(this.authUser._id);         // sets up listeners

    this.route.paramMap.subscribe(params => {
      this.userId = params.get('id');
      if (!this.userId) {
        console.error('❌ No partner ID in route');
        return void this.router.navigate(['/']);
      }

      /* partner profile, misc one-off listeners … */
      this.getUser();

      window.addEventListener('partner-answered', this.partnerAnsweredListener, { once:false });
      window.addEventListener('peer-call-error', () => {
        this.toastService.presentStdToastr('Call could not be established');
        this.cancel(true);
      });

      /* caller / callee mode */
      this.route.queryParamMap.subscribe(qp => {
        this.answer = qp.get('answer') === 'true';
        if (!this.answer) {
          console.log('🔄 Caller mode — call will start on view enter');
        } else {
          this.startUnansweredTimeout();    // ring-in side
        }
      });
    });

  } catch (err) {
    console.error('❌ ngOnInit() aborting:', err);
    this.router.navigate(['/auth/signin']);
  }
}


  private handleBackButton() {
    console.log('🔙 Handling back button');
    this.cleanupResources();
    this.location.back();
  }

// Remove ionViewDidLeave and keep ionViewWillLeave
// In your video component

private showSelfPreview(stream: MediaStream): void {
  const el = this.myVideoRef.nativeElement;

  if (!el.srcObject)  { el.srcObject = stream; }
  el.muted = true;                           // autoplay allow-list

  const playNow = () => el.play().catch(() => {});
  if (el.readyState >= 1)           { playNow(); }      // metadata present
  else                              { el.onloadedmetadata = playNow; }
}


  private cleanupResources() {
    console.log('🧹 Cleaning up resources');
    
    // 1. Remove event listeners
    window.removeEventListener("partner-answered", this.partnerAnsweredListener);
    
    // 2. Clean up audio
    if (this.audio) {
      this.audio.pause();
      this.audio.src = '';
      this.audio = null;
    }
    
    // 3. Clean up WebRTC
    this.webRTC.close();
    
    // 4. Clean up video elements
    if (this.myEl) {
      this.myEl.srcObject = null;
      this.myEl.pause();
    }
    if (this.partnerEl) {
      this.partnerEl.srcObject = null;
      this.partnerEl.pause();
    }
    
    // 5. Clean up socket
    this.leaveCallRoom();            // 👈 NEW (optional here)

  }




// Add these methods to your component
startCallTimer() {
  this.callStartTime = Date.now();

  this.callTimerInterval = setInterval(() => {
    if (!this.callStartTime) return;

    const elapsedMs = Date.now() - this.callStartTime;
    const totalSeconds = Math.floor(elapsedMs / 1000);
    const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    this.callDuration = `${minutes}:${seconds}`;
  }, 1000); // update every second
}

startMissedCallTimeout() {
  this.callTimeout = setTimeout(() => {
    if (!this.answered) {
      console.log('⏰ No answer in 30 sec — cancelling call');
      this.cancel();  // Will emit cancel-call to partner
    }
  }, 30000);
}

stopCallTimer() {
  clearInterval(this.callTimerInterval);
  this.callTimerInterval = null;
  this.callStartTime = null;
  this.callDuration = '00:00';
}
async ionViewWillEnter() {
  try {
    this.pageLoading = true; 
    this.cdr.detectChanges();

    await this.webRTC.createPeer(this.authUser._id); // only once
    await this.waitForVideoElements();
    
    await this.webRTC.init(this.myEl, this.partnerEl);

    if (!this.answer) {
      await this.placeCall(); 
      this.startMissedCallTimeout();
      console.log('🔄 caller mode');
    }


  } catch (e) {
    console.error(e);
    this.toastService.presentStdToastr('Failed to start video call.');
    this.router.navigate(['/']);
  } finally {
    this.pageLoading = false; 
    this.cdr.detectChanges();
  }
}




// video.component.ts  (somewhere near other helpers)
private wireHangup(mc: MediaConnection) {
  mc.once('close', () => {
    // Prevent re-entry if we fired the close ourselves
    if (this.hangupHandled) return;
    this.hangupHandled = true;
    this.ngZone.run(() => this.closeCall());   // run inside Angular
  });
}


private async waitForVideoElements(): Promise<void> {
  return new Promise((resolve, reject) => {
    const maxAttempts = 30; // Increased further
    let attempts = 0;
    
    const checkElements = () => {
      attempts++;
      
      // Use both ViewChild and direct DOM query with fallbacks
      this.myEl = this.myVideoRef?.nativeElement || 
                 document.querySelector('#my-video') as HTMLVideoElement;
      this.partnerEl = this.partnerVideoRef?.nativeElement || 
                      document.querySelector('#partner-video') as HTMLVideoElement;
      
      if (this.myEl && this.partnerEl) {
        console.log('✅ Video elements found after', attempts, 'attempts');
        resolve();
      } else if (attempts >= maxAttempts) {
        console.error('Video elements not found:', {
          myVideoRef: !!this.myVideoRef,
          partnerVideoRef: !!this.partnerVideoRef,
          myVideoDOM: !!document.querySelector('#my-video'),
          partnerVideoDOM: !!document.querySelector('#partner-video')
        });
        reject(new Error(`Video elements not found after ${maxAttempts} attempts`));
      } else {
        setTimeout(checkElements, 150); // Slightly longer delay
      }
    };
    
    // Initial check after a brief delay to allow rendering
    setTimeout(checkElements, 100);
  });
}

handleVideoError(type: 'local' | 'partner') {
  console.error(`${type} video error`);
  this.toastService.presentStdToastr(`${type} video failed to load`);
}
getUserId() {
  this.route.paramMap.subscribe((params) => {
      this.userId = params.get('id');
      console.log("🟢 Retrieved Parternrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr User ID:", this.userId);
      
      this.route.queryParamMap.subscribe((query) => {
          this.answer = query.get('answer') ? true : false;
          console.log("🟢 Answer Mode:", this.answer);
          
          this.getUser();
      });
  });
}


getUser() {
  console.log('Fetching partner profile for ID:', this.userId);
  this.userService.getUserProfile(this.userId).subscribe(
    async (resp: any) => {
      this.pageLoading = false;
      console.log('Partner profile response:', resp);

      const userData = resp.data || resp;

      if (userData) {
        try {
          console.log('Raw userData:', userData);
          this.partner = userData instanceof User ? userData : new User().initialize(userData);
          console.log('Partner initialized successfully:', this.partner);
        } catch (error) {
          console.error('Error initializing partner user:', error);
          this.handleUserInitError();
        }
      } else {
        console.error('Invalid response data: userData is null or undefined');
        this.handleUserInitError();
      }
    },
    (err) => {
      console.error('Error fetching partner profile:', err);
      this.pageLoading = false;
      this.location.back();
      this.toastService.presentStdToastr('Cannot make this call, try again later');
    }
  );
}


  async getAuthUser(): Promise<void> {
    return new Promise((resolve) => {
      console.log('🔍 Starting authentication process...');
  
  const getToken = async (): Promise<string | null> => {
    console.log('🔑 Attempting to retrieve token...');
    if (this.isCordovaAvailable()) {
      console.log('📱 Cordova platform detected - using NativeStorage');
      try {
        const token = await this.nativeStorage.getItem('token');
        console.log('✅ Token retrieved from NativeStorage');
        return token;
      } catch (err) {
        console.warn("⚠️ Failed to retrieve token from NativeStorage:", err);
        return null;
      }
    } else {
      console.log('🖥️ Web platform detected - using localStorage');
      const token = localStorage.getItem('token');
      console.log(token ? '✅ Token retrieved from localStorage' : '❌ No token in localStorage');
      return token;
    }
  };

  getToken().then((token) => {
    if (!token) {
      console.error("❌ No token found in storage");
      this.router.navigate(['/auth/signin']);
      return;
    }

    console.log('🔍 Token found, decoding...');
    try {
      const decoded = this.jwtHelper.decodeToken(token);
      console.log('🔍 Decoded token content:', {
        idPresent: !!decoded?._id,
        firstNamePresent: !!decoded?.firstName,
        lastNamePresent: !!decoded?.lastName,
        avatarPresent: !!decoded?.mainAvatar
      });

      if (!decoded?._id) {
        console.error("❌ Invalid token structure - missing _id");
        this.router.navigate(['/auth/signin']);
        return;
      }

      // ONLY use the decoded token data
      this.authUser = new User().initialize({
        _id: decoded._id,
        firstName: decoded.firstName || '',
        lastName: decoded.lastName || '',
        mainAvatar: decoded.mainAvatar || ''
      });
      
          console.log("🔐 Auth user initialized:", this.authUser._id);
          resolve();
        } catch (error) {
          console.error("❌ Token decoding failed:", error);
          this.router.navigate(['/auth/signin']);
        }
      });
    });
  }


  handleUserInitError() {
    this.pageLoading = false;
    this.toastService.presentStdToastr('User not found, please log in again');
    this.router.navigate(['/auth/signin']);
  }


  async initializeSocket(userId: string) {
    try {
        if (this.socket) {
            console.warn("⚠️ WebSocket already initialized. Checking connection...");
            if (this.socket.connected) {
                console.log("✅ WebSocket is already connected.");
                return;
            } else {
                console.warn("🔄 WebSocket was disconnected. Attempting to reconnect...");
                this.socket.disconnect(); // Ensure cleanup before reconnecting
            }
        }

        console.log("🔵 Initializing WebSocket for userId:", userId);
        await SocketService.initializeSocket();

        // ✅ Retry WebSocket retrieval to ensure it's available
        let attempts = 0;
        while (!this.socket && attempts < 3) {
            this.socket = await SocketService.getSocket();
            if (!this.socket) {
                console.warn(`⚠️ WebSocket still not available. Retrying (${attempts + 1}/3)...`);
                await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 sec before retrying
            }
            attempts++;
        }

        if (!this.socket) {
            console.error("❌ WebSocket initialization failed after multiple attempts.");
            return;
        }

        console.log("✅ WebSocket instance retrieved:", this.socket.id);
        this.listenForVideoCallEvents(); // Ensure event listeners are set up

    } catch (error) {
        console.error("❌ WebSocket initialization failed:", error);
    }
}

  
listenForVideoCallEvents() {
  if (!this.socket) {
    console.error('❌ WebSocket not initialized. Cannot listen for video call events.');
    return;
  }

  /* ── 1 ▸ make sure we never attach duplicates ─────────────────────── */
  this.socket.off('video-call-started');
  this.socket.off(VideoEvents.CANCELED);
  this.socket.off(VideoEvents.ENDED);
  this.socket.off('video-call-failed');

  /* ── 2 ▸ ringing just started (incoming side) ─────────────────────── */
  this.socket.on('video-call-started', (data) => {
    console.log('📞 Video call started:', data);
    this.ringer.start('calling.mp3');          // play ringing tone
  });

  /* ── 3 ▸ caller canceled before call was answered ─────────────────── */
  this.socket.on(VideoEvents.CANCELED, async () => {
    console.log('🚫 Video call canceled by other user.');

    this.ringer.stop();
    this.webRTC.close();

    // clear local <video> elements
    if (this.myEl)      { this.myEl.srcObject      = null; this.myEl.pause(); }
    if (this.partnerEl) { this.partnerEl.srcObject = null; this.partnerEl.pause(); }

    this.messengerService.sendMessage({ event: 'stop-audio' });
    await this.toastService.presentStdToastr('Call was canceled.');
    this.leaveCallRoom();

    if (this.router.url.includes('/video')) {
      this.router.navigate(['/tabs/messages/list']);
    }
  });

  /* ── 4 ▸ partner hung up after call was connected ─────────────────── */
  this.socket.on(VideoEvents.ENDED, async () => {
    console.log('📴 Video call ended by partner.');
    this.ringer.playOnce('call-cenceled.mp3');

    this.isRemoteEnd = true;               // prevent echo re-emit
    await this.toastService.presentStdToastr('Call ended by partner.');

    this.ringer.stop();
    this.leaveCallRoom();
    this.closeCall();                      // local teardown
  });

  /* ── 5 ▸ generic error channel (kept unchanged) ───────────────────── */
  this.socket.on('video-call-failed', (error) => {
    console.error('❌ Video call error:', error);
    this.ringer.playOnce('call-cenceled.mp3');
    this.toastService.presentStdToastr('Call failed. Please try again.');
    this.cancel();
  });

  /* ── 6 ▸ unexpected socket disconnect ─────────────────────────────── */
  this.socket.on('disconnect', () => {
    console.warn('⚠️ WebSocket disconnected. Attempting auto-reconnect…');
    setTimeout(() => this.initializeSocket(this.userId), 2000);
  });
}


  
private leaveCallRoom() {
  if (this.socket && this.socket.connected) {
    this.socket.emit('leave-call', {
      room : this.userId,        // or whatever room you use
      user : this.authUser._id,
    });
  }
}

  async init(myVideoEl: HTMLVideoElement, partnerVideoEl: HTMLVideoElement): Promise<void> {
    try {
        // ✅ Request user media (camera + mic)
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        await this.webRTC.listAllMediaDevices();

        if (!stream) {
            throw new Error("❌ Failed to get media stream.");
        }

        // ✅ Assign local stream to video element
        myVideoEl.srcObject = stream;

        // ✅ Store the stream for later use
        this.localStream = stream;

        console.log("✅ Local video stream initialized.");

    } catch (err) {
        console.error("❌ Error initializing video:", err);
    }
}

async emitWebSocketEvent(eventName: string, data: any) {
  if (!this.socket) {
      console.warn("⚠️ WebSocket is not ready. Trying to retrieve...");
      this.socket = await SocketService.getSocket();

      if (!this.socket) {
          console.error("❌ WebSocket is still not available. Aborting event emit.");
          return;
      }
  }

  if (!this.socket.connected) {
      console.warn("⚠️ WebSocket is disconnected. Attempting to reconnect...");
      await this.initializeSocket(this.userId);
  }

  console.log(`📤 Emitting event: ${eventName}`, data);
  this.socket.emit(eventName, data);
  
}




  waitForAnswer() {
    const timer = setInterval(() => {
      if (this.partnerEl && this.partnerEl.srcObject) {
        this.ringer.stop();
        this.messengerService.sendMessage({ event: 'stop-audio' });
        this.answered = true;
        clearTimeout(this.callTimeout);

        this.cdr.detectChanges(); // ✅ Force update
        this.countVideoCalls();
        this.swapVideo('my-video');
        clearInterval(timer);
      }
    }, 10);
  }

  getVideoCalls() {
    return this.nativeStorage.getItem('videoCalls').then(
      (calls) => {
        return calls;
      },
      (err) => {
        return [];
      }
    );
  }

  countVideoCalls() {
    this.getVideoCalls().then((calls) => {
        calls = Array.isArray(calls) ? calls : []; // ✅ Ensure it's an array
        calls = calls.filter((call) => new Date().getTime() - call.date < 24 * 60 * 60 * 1000);
        
        calls.push({
          id: this.authUser._id, // Changed from this.user.id
          date: new Date().getTime(),
        });

        this.nativeStorage.setItem('videoCalls', calls);
    });
}


  swapVideo(topVideo: string) {
    this.topVideoFrame = topVideo;
  }



  async closeCall(): Promise<void> {
    console.log('📴 Closing the call with full cleanup…');
  
    /* 1 ─ emit “ENDED” once (unless partner fired first) */
    if (!this.isRemoteEnd && this.socket?.connected) {
      await this.emitWebSocketEvent(VideoEvents.ENDED, {
        from: this.authUser._id,
        to  : this.userId,
      });
    }
  
    /* 2 ─ stop any ringing tone */
    this.ringer.stop();
  
    /* 3 ─ stop and disable ALL local tracks */
    this.webRTC.myStream?.getTracks().forEach(t => {
      t.stop();
      t.enabled = false;
    });
  
    /* 4 ─ clear <video> elements */
    if (this.myEl)      { this.myEl.srcObject      = null; this.myEl.pause(); }
    if (this.partnerEl) { this.partnerEl.srcObject = null; this.partnerEl.pause(); }
  
    /* 5 ─ close the WebRTC helper */
    this.webRTC.close();
    this.localStream = null;
  
    /* 6 ─ missed-call logic for unanswered outbound calls */
    if (!this.answered && !this.answer && this.socket?.connected) {
      this.socket.emit(VideoEvents.CANCELED, {
        from: this.authUser._id,
        to  : this.userId,
      });
      await this.webRTC.registerMissedCall(this.userId);
    }
  
    /* 7 ─ tidy up socket room (optional) */
    this.leaveCallRoom();
  
    /* 8 ─ navigate away */
    setTimeout(() => {
      this.router.navigate(['/tabs/messages/list']);
    }, 500);
  }


  async cancel(manualClose = false): Promise<void> {
    console.log('❌ Cancelling call…');
  
    this.ringer.stop();
    this.ringer.start('call-cenceled.mp3');
    setTimeout(() => this.ringer.stop(), 1000);
  
    if (this.endingCall) { return; }      // guard
    this.endingCall = true;
    this.cdr.detectChanges();
    
    this.messengerService.sendMessage({ event: 'stop-audio' });
  
    // local teardown
    this.webRTC.close();
    if (this.myEl)      { this.myEl.srcObject      = null; this.myEl.pause(); }
    if (this.partnerEl) { this.partnerEl.srcObject = null; this.partnerEl.pause(); }
    this.localStream = null;
  
    // notify peer (but keep socket alive)
    if (this.socket?.connected) {
      if (!this.answered) {
        this.socket.emit(VideoEvents.CANCELED, {           // ⬅ enum
          from: this.authUser._id,
          to  : this.userId,
        });
        await this.webRTC.registerMissedCall(this.userId);
      } else {
        this.socket.emit(VideoEvents.ENDED, {              // ⬅ enum
          from: this.authUser._id,
          to  : this.userId,
        });
      }
    }
    this.endingCall = false;

    if (!manualClose) {
      this.router.navigate(['/tabs/messages/list']);
    }
  }
  
  
  



startUnansweredTimeout() {
  this.clearUnansweredTimeout(); // cleanup if needed
  this.unansweredTimeout = setTimeout(() => {
    if (!this.answered) {
      console.warn('⏱️ Call unanswered after 30 seconds. Closing...');

      this.webRTC.registerMissedCall(this.userId);

      this.closeCall(); // this will also register missed call if not answered
    }
  }, 30000); // 30 seconds
}

clearUnansweredTimeout() {
  if (this.unansweredTimeout) {
    clearTimeout(this.unansweredTimeout);
    this.unansweredTimeout = null;
  }
}

async placeCall() {
  try {
    this.placingCall = true;
     this.calling     = true; 
    this.ringer.start('ringing.mp3'); // ✅ Caller hears ringing
    const socket = await SocketService.getSocket(); 
    socket.emit('call-user', this.partnerId);
    // ✅ Ensure peer is created
    await this.webRTC.createPeer(this.authUser._id);

    // ✅ Ensure video elements are available
    if (!this.myEl || !this.partnerEl) {
      await this.waitForVideoElements();
    }


      if (this.localStream &&
        !this.localStream.getTracks().some(t => t.readyState === 'live')) {
      this.localStream = null;              // ❌ discard
    }
    
    if (!this.localStream) {
      this.localStream = await this.webRTC.getUserMedia();  // ✅ fresh grab
      if (!this.localStream) {
        this.toastService.presentStdToastr('Cannot access camera / mic');
        return;
      }
      this.showSelfPreview(this.localStream);
    }

    // ✅ Start call
    const mc = await this.webRTC.startCall(this.userId, this.localStream);
    this.wireHangup(mc);
    mc.on('stream', (remote) => this.attachRemoteStream(remote));
    mc.on('error',  (e) => console.error('[call] error', e));

    this.calling = true;
  } catch (err: any) {
    this.toastService.presentStdToastr(err.message ?? String(err));
  } finally {
    this.placingCall = false;
  }
}



private attachRemoteStream(remote: MediaStream): void {
  const el = this.partnerVideoRef.nativeElement;
  el.srcObject = remote;

  const playNow = () => el.play().catch(() => {});
  if (el.readyState >= 1) { playNow(); }
  else                    { el.onloadedmetadata = playNow; }
}


// In video.component.ts - modify the answerCall() method
async answerCall(): Promise<void> {

  /* make sure cached stream is still live */
if (this.localStream &&
  !this.localStream.getTracks().some(t => t.readyState === 'live')) {
this.localStream = null;
}

  try {
    this.answeringCall = true;
    this.ringer.stop(); // ✅ Stop 'calling' sound on receiver
    this.startCallTimer();
    /* ── grab cam/mic only once ───────────────────────────── */
    if (!this.localStream) {
      this.localStream = await this.webRTC.getUserMedia();
      this.showSelfPreview(this.localStream);        // local tile
    }

    const incoming = WebrtcService.call;
    if (!incoming) { throw new Error('No incoming call'); }

    incoming.answer(this.localStream);
    this.wireHangup(incoming); 
    incoming.on('stream',  (remote) => this.attachRemoteStream(remote));
    incoming.on('error',   (e)      => console.error('[answer] error', e));
    this.ringer.stop();

    this.answered = true;
    this.countVideoCalls();

  } finally {
    this.answeringCall = false;
    this.cdr.detectChanges();
  }
}



  toggleAudio() {
    if (!this.webRTC.myStream) {
      console.error("❌ Cannot toggle audio: Media stream is not initialized.");
      return;
    }
    this.audioEnabled = this.webRTC.toggleAudio();
  }
  
  toggleCamera() {
    if (!this.webRTC.myStream) {
      console.error("❌ Cannot toggle camera: Media stream is not initialized.");
      return;
    }
    this.cameraEnabled = this.webRTC.toggleCamera();
  }
  

  toggleCameraDirection() {
    this.webRTC.toggleCameraDirection();
  }


  
  isCordovaAvailable(): boolean {
    return !!(window.cordova && window.cordova.platformId !== 'browser');
  }
}