// events.ts  (create once and import everywhere)
export enum VideoEvents {
    CANCELED = 'video-canceled',      // fired while the call is still ringing
    ENDED    = 'video-call-ended',    // fired after the call is connected
  }
  