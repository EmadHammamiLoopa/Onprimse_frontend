// cordova.d.ts
interface Window {
    cordova?: any;
  }
  